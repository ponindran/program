﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Twinkle.BaseModel
{
    public interface IBaseModel
    {
        string CreatedOn { get; set; }
    }
}
